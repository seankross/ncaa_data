library(gdata)

an = tbl_df(
	read.csv("all_ncaa_data_10_13.csv")
)

dt = colsplit(an$association,'\\(',c('division','other'))
dt$division = dt$division %>>% Trim()
an$men_revenue = an$men_revenue %>>% as.numeric()
an$women_revenue = an$women_revenue %>>% as.numeric()
an$association %>>% unique()
ncaa = unique(an %>%
	select(association) %>%
	arrange(association))
ncaa =ncaa$association
ncaa = ncaa[4:10]
an$association
totals_type =
	an %>%
	filter(!is.na(sport_label),association %in% ncaa) %>%
	group_by(year,association,sport_label) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_type$total_revenue =
	totals_type$men_revenue + totals_type$women_revenue
write.csv(totals_type,'total_by_ncca_type_by_power_sport.csv',row.names = F)


totals_sport =
	an %>%
	filter(!is.na(sport_label), association_name %in% ncaa) %>%
	group_by(year,sport,sport_label,association_name) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_sport$total_revenue =
	totals_sport$men_revenue + totals_sport$women_revenue
write.csv(totals_sport,'total_by_ncaa_by_all_sport.csv',row.names = F)

totals_type_conference =
	an %>%
	filter(!is.na(sport_label), association_name %in% ncaa) %>%
	group_by(year,conference,association_name,sport_label) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_type_conference$total_revenue =
	totals_type_conference$men_revenue + totals_type_conference$women_revenue

totals_sport_conference =
	an %>%
	filter(!is.na(sport_label), association_name %in% ncaa) %>%
	group_by(year,sport,conference,association_name,sport_label) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_sport_conference$total_revenue =
	totals_sport_conference$men_revenue + totals_sport_conference$women_revenue

write.csv(totals_sport_conference,'total_by_ncaa_type_by_all_sport_conference.csv',row.names = F)
write.csv(totals_type_conference,'total_by_ncaa_type_sport_type_conference.csv',row.names = F)

totals_type_school_conference =
	an %>%
	filter(!is.na(sport_label), association_name %in% ncaa) %>%
	group_by(year,school,conference,association_name,sport_label) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_type_school_conference$total_revenue =
	totals_type_school_conference$men_revenue + totals_type_school_conference$women_revenue

totals_sport_school_conference =
	an %>%
	filter(!is.na(sport_label), association_name %in% ncaa) %>%
	group_by(year,sport,school,conference,association_name,sport_label) %>%
	summarise(men_revenue = sum(men_revenue,na.rm = T),
						women_revenue = sum(women_revenue,na.rm = T)
	)

totals_sport_school_conference$total_revenue =
	totals_sport_school_conference$men_revenue + totals_sport_school_conference$women_revenue

write.csv(totals_sport_school_conference,'total_by_all_sport_ncaa_type_school_conference.csv',row.names = F)
write.csv(totals_type_school_conference,'totals_type_school_ncaa_type_conference.csv',row.names = F)
write.csv(all_ncaa,'all_ncaa_data_new_00_13.csv',row.names = F)
